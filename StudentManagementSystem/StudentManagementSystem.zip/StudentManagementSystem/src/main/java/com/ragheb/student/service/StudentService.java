package com.ragheb.student.service;

import com.ragheb.student.entity.Student;

import java.util.List;

public interface StudentService {
    public List<Student> getAllStudents();
    public Student saveStudent(Student student);
    public Student getStudentById(Integer id);
    public void deleteStudentById(Integer id);
}
